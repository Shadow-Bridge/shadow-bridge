﻿#include <SFML/Graphics.hpp>
#include <SFML/Main.hpp>
#include <random>
#include <string>

//Random number generator
std::random_device rd;
std::mt19937 rng(rd());
std::uniform_int_distribution<int> uni(256,1024);

int m_frame = 0;
int m2_frame = 0;
int m3_frame = 0;
int m4_frame = 0;
int blue_frame = 0;
int blue_atk_frame = 0;
int red_ghoul_attack_frame = 0;
int red_ghoul_attack_frame2 = 0;
int red_ghoul_attack_frame3 = 0;
int red_ghoul_attack_frame4 = 0;
int attack_frame = 0;
int bullet_direction = 1;
int orientation = 1;
int rg1_orient = 1;
int rg2_orient = 1;
int rg3_orient = 1;
int rg4_orient = 1;
int start = 0;
int isStory = 0;
int statusx = 34;
int statusy = 23;

int health = 100;
int healthx = 32;
int healthy = 30;

int mana = 100;
int manax = 34;
int manay = 21;

int gold = 0;

int x = 0;
int y = 0;
float height = 0;
float width = 0;
float inity = 0;

// Define velocity, acceleration and gravity. I hate physics.

float velocityY = 0;
float accelerationY = 0;
float gravity = 0.85;

// A small boolean to keep track of whether our player is already jumping.
bool isJumping = false;
bool isPlaying = true;
bool isPause = false;
bool isAttacking1 = false;
bool isAttacking2 = false;
bool isAttacking3 = false;
bool isAttacking4 = false;
bool blue_atk = false;
bool bullet_spawn = false;
bool stop_anim = false;

//Keeping track of whether or not the player character is performing an action

bool playerBusy = false;

// A function that makes sure our player moves nicely through space-time
void updateMovement() {
	if (y < inity)
	velocityY += gravity;
	else if (y > inity)
	y = inity;
	velocityY += accelerationY;
	y += velocityY;
}

int NumDigits(int x) {
	x = abs(x);
	return (x < 10 ? 1 :
	(x < 100 ? 2 :
	(x < 1000 ? 3 :
	(x < 10000 ? 4 :
	(x < 100000 ? 5 :
	(x < 1000000 ? 6 :
	(x < 10000000 ? 7 :
	(x < 100000000 ? 8 :
	(x < 1000000000 ? 9 :
	10)))))))));
}

int main() {
	width = 1920;
	height = 1080;

	// Create the main window and limit its framerate
	sf::RenderWindow window(sf::VideoMode(width, height), "SFML window", sf::Style::Fullscreen);
	window.setFramerateLimit(60);
	window.sf::Window::requestFocus();
	window.setVerticalSyncEnabled(true);

	float bg_ratio = height / 1024;

	sf::Texture t_splash;
	if (!t_splash.loadFromFile("assets/splash.png"))
		return EXIT_FAILURE;
	sf::Sprite splash(t_splash);
	splash.setScale(bg_ratio,bg_ratio);
	
	sf::Texture t_startmenu;
	if (!t_startmenu.loadFromFile("assets/start.png"))
		return EXIT_FAILURE;
	sf::Sprite startmenu(t_startmenu);
	
	startmenu.setPosition(128, -128);
	
	sf::Texture t_logo;
	if (!t_logo.loadFromFile("assets/logo.png"))
		return EXIT_FAILURE;
	sf::Sprite logo(t_logo);
	
	logo.setScale(0.6,0.6);
	logo.setOrigin(1920/2, 1080/2);
	logo.setPosition(1920/2, 256);
	
	sf::Texture t_story;
	if (!t_story.loadFromFile("assets/story.png"))
		return EXIT_FAILURE;
	sf::Sprite story(t_story);

	// Initialize the background
	sf::Texture t_background;
	if (!t_background.loadFromFile("assets/background.jpg"))
	return EXIT_FAILURE;
	sf::Sprite background(t_background);
	background.setScale(bg_ratio, bg_ratio);

	sf::Font font;
	if (!font.loadFromFile("assets/font.ttf"))
	return EXIT_FAILURE;

	sf::Texture t_status;
	if (!t_status.loadFromFile("assets/status_bar.png"))
	return EXIT_FAILURE;
	sf::Sprite status_bar(t_status);

	sf::Texture t_health;
	if(!t_health.loadFromFile("assets/health_bar.png"))
	return EXIT_FAILURE;
	sf::Sprite health_bar(t_health);

	sf::Texture t_mana;
	if(!t_mana.loadFromFile("assets/mana_bar.png"))
	return EXIT_FAILURE;
	sf::Sprite mana_bar(t_mana);

	// Initialize the player character
	sf::Texture t_player;
	if (!t_player.loadFromFile("assets/player.png"))
	return EXIT_FAILURE;
	sf::Sprite player(t_player);

	//Initialize the bullet
	sf::Texture t_bullet;
	if (!t_bullet.loadFromFile("assets/bullet.png"))
	return EXIT_FAILURE;
	sf::Sprite bullet(t_bullet);

	//Initialize the endscreen graphic
	sf::Texture t_endscreen;
	if (!t_endscreen.loadFromFile("assets/endscreen.png"))
	return EXIT_FAILURE;
	sf::Sprite endscreen(t_endscreen);

	sf::Texture t_menu;
	if (!t_menu.loadFromFile("assets/menu.png"))
	return EXIT_FAILURE;
	sf::Sprite menu(t_menu);

	//Initialize the red ghoul
	sf::Texture t_red_ghoul;
	if (!t_red_ghoul.loadFromFile("assets/red_ghoul.png"))
	return EXIT_FAILURE;
	sf::Sprite red_ghoul1(t_red_ghoul);
	sf::Sprite red_ghoul2(t_red_ghoul);
	sf::Sprite red_ghoul3(t_red_ghoul);
	sf::Sprite red_ghoul4(t_red_ghoul);
		sf::Texture t_blue;
	if (!t_blue.loadFromFile("assets/blue_ghoul.png"))
	return EXIT_FAILURE;
	sf::Sprite blue(t_blue);

	// Add a clock
	sf::Clock clock;
	sf::Clock attackClock;
	sf::Clock attackTimer;
	sf::Clock mana_clock;
	sf::Clock endClock;
	sf::Clock rg_attackClock;
	sf::Clock rg2_attackClock;
	sf::Clock rg3_attackClock;
	sf::Clock rg4_attackClock;
	sf::Clock blue_clock;
	sf::Clock bulletClock;

	sf::Vector2i mouse;

	status_bar.setPosition(statusx, statusy);
	status_bar.setScale(0.862*2.5, 0.862*2.5);
	health_bar.setPosition(healthx+2, healthy-9);
	health_bar.setScale(0.862*2.5, 0.862*2.5);
	mana_bar.setPosition(manax, manay);
	mana_bar.setScale(0.862*2.5, 0.862*2.5);

	sf::Text health_val;
	std::string health_str;
	health_val.setFont(font);
	health_val.setCharacterSize(10);
	health_val.setFillColor(sf::Color::Black);
	health_val.setPosition(healthx+2 + 108*bg_ratio, healthy-5 + 62*bg_ratio);

	sf::Text mana_val;
	std::string mana_str;
	mana_val.setFont(font);
	mana_val.setCharacterSize(10);
	mana_val.setFillColor(sf::Color::White);
	mana_val.setPosition(healthx+3 + 108*bg_ratio, healthy-9 + 75*bg_ratio);

	sf::Text gold_val;
	std::string gold_str;
	gold_val.setFont(font);
	gold_val.setCharacterSize(16);
	gold_val.setFillColor(sf::Color::Yellow);

	float player_scale = 3.5 * bg_ratio;

	// Set player coordinates
	inity = height - (height/7) - (50*player_scale);
	y = inity;
	x = 128+128;

	float leftedge = 128 + 64;
	float rightedge = width - 128 - 64;

	player.setPosition(x, y);
	player.setOrigin(104/2, 95/2); // Set the origin to roughly the center of the sprite, for collision detection purposes
	player.setScale(player_scale, player_scale);  // Resize the player - a bit too small for comfort.
	player.setTextureRect(sf::IntRect(334, 309, 95, 104)); // Switch to the first frame of the player spritesheet

	float rg_scale = 4.5*bg_ratio;
	float rg1_x = width + uni(rng);
	float rg1_y = height - (height/7) - (16*rg_scale);
	float rg2_x = width + uni(rng);
	float rg2_y = height - (height/7) - (16*rg_scale);
	float rg3_x = width + uni(rng);
	float rg3_y = height - (height/7) - (16*rg_scale);
	float rg4_x = width + uni(rng);
	float rg4_y = height - (height/7) - (16*rg_scale);
	float blue_scale = 4.5*bg_ratio;
	float bluex = width + 2048 + uni(rng);
	float bluey = height - 2*(height/7);
	float bulletx = 9000;
	float bullety = 9000;

	red_ghoul1.setPosition(rg1_x, rg1_y);
	red_ghoul1.setOrigin(61/2, 42/2);
	red_ghoul1.setScale(rg_scale, rg_scale);
	red_ghoul1.setTextureRect(sf::IntRect(124, 100, 54, 49));

	red_ghoul2.setPosition(rg2_x, rg2_y);
	red_ghoul2.setOrigin(61/2, 42/2);
	red_ghoul2.setScale(rg_scale, rg_scale);
	red_ghoul2.setTextureRect(sf::IntRect(128, 101, 54, 49));

	red_ghoul3.setPosition(rg3_x, rg3_y);
	red_ghoul3.setOrigin(61/2, 42/2);
	red_ghoul3.setScale(rg_scale, rg_scale);
	red_ghoul3.setTextureRect(sf::IntRect(128, 101, 54, 49));

	red_ghoul4.setPosition(rg4_x, rg4_y);
	red_ghoul4.setOrigin(61/2, 42/2);
	red_ghoul4.setScale(rg_scale, rg_scale);
	red_ghoul4.setTextureRect(sf::IntRect(128, 101, 54, 49));
		blue.setPosition(bluex, bluey);
	blue.setOrigin(64/2, 55/2);
	blue.setScale(1.5*blue_scale, 1.75*blue_scale);
	blue.setTextureRect(sf::IntRect(0, 0, 64, 52));
		bullet.setPosition(9000, 9000);
	bullet.setOrigin(6,2);
	bullet.setScale(1.5*blue_scale, 1.75*blue_scale);

	int endscreenx = (width/2) - 269*1.5;
	int endscreeny = -800;
	endscreen.setPosition(endscreenx, endscreeny);
	endscreen.setTextureRect(sf::IntRect(0, 0, 539, 523));
	endscreen.setScale(1.5, 1.5);

	int menux = (width/2) - 269*1.5;
	int menuy = -800;
	menu.setPosition(menux, menuy);
	menu.setTextureRect(sf::IntRect(0, 0, 539, 523));
	menu.setScale(1.5, 1.5);
	
	sf::Event event;

	// Start the game loop
	while (window.isOpen())
	{
		window.clear();
		mouse = sf::Mouse::getPosition();
		if (start == 0) {
		if (isStory == 0) {
			window.draw(splash);
			window.draw(startmenu);
			window.draw(logo);
			if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
				if (((mouse.x > 136) && (mouse.x < 428)) && ((mouse.y > 768 - 128) && (mouse.y < 810 - 128))) {
					isStory = 1;
					window.clear();
				}
				if (((mouse.x > 128+55) && (mouse.x < 355+128)) && ((mouse.y > 955 - 128) && (mouse.y < 1020 - 128))) {
					return EXIT_SUCCESS;
				}
				
			}
			while (window.pollEvent(event))
			{
				switch (event.type)
				{
				case sf::Event::Closed:
					window.close();
					break;
				case sf::Event::KeyPressed:
					if (event.key.code == sf::Keyboard::F4) {
						return EXIT_SUCCESS;
					}
					break;
				default:
					break;
				}
			}
		}
		if (isStory == 1) {
				window.draw(story);
				if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
					if (((mouse.x > 610) && (mouse.x < 1280)) && ((mouse.y > 850) && (mouse.y < 1070))) {
						start = 1;
						window.clear();
					}
				}
				while (window.pollEvent(event))
				{
					switch (event.type)	{
						case sf::Event::Closed:
							window.close();
							break;
						case sf::Event::KeyPressed:
							if (event.key.code == sf::Keyboard::F4) {
								return EXIT_SUCCESS;
							}
							break;
						default:
							break;
					}
			}
		}
		}
		if (start == 1) {
			
			// Events - like jumping and closing the window and shooting bullets.
			// First of all, let's make sure we aren't flying into outer space
			// if our player holds the Space key for too long.
			isStory = 0;
			window.setKeyRepeatEnabled(false);

			while (window.pollEvent(event))
			{
				switch (event.type)
				{
					// Let's make sure the window actually closes when we want it to.
				case sf::Event::Closed:
					window.close();
					break;

					// Let's teach our pirate how to jump.
					// And by that, I mean let's launch him into the air at a speed of 10 pixels per frame.
				case sf::Event::KeyPressed:
					if (isPlaying) {
						if (event.key.code == sf::Keyboard::Up) {
							if (isJumping == false) {
								velocityY = -25;
								isJumping = true;
							}
						}
						if (event.key.code == sf::Keyboard::Space) {
							if ((playerBusy == false) and (mana >= 15)) {
								playerBusy = true;
								player.setTextureRect(sf::IntRect(0, 106, 94, 103));
								mana -= 15;
							}
						}
					}
					if (event.key.code == sf::Keyboard::Escape) {
						if (isPause == false)
						isPause = true;
						else {
							isPause = false;
						}
					}
					if (event.key.code == sf::Keyboard::F4) {
						health = 0;
					}
					if (event.key.code == sf::Keyboard::F5) {
						health = 10000;
					}
					break;
				default:
					break;
				}
			}
			
			
			if (isPlaying) {
				//Let the player skedaddle across the screen, but not too far - inside the boundaries we defined earlier
				if ((x >= leftedge) && (x <= rightedge)) {
					if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
					{
						if (isJumping) {
							x = x + 9;
						}
						else {
							x = x + 6;
						}
						player.setTextureRect(sf::IntRect(334, 309, 95, 104));
						orientation = 1;
					}

					if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
					{
						if (isJumping) {
							x = x - 9;
						}
						else {
							x = x - 6;
						}
						player.setTextureRect(sf::IntRect(239, 309, 95, 104));
						orientation = -1;
					}

					//Sometimes the player ends up magically outside the boundaries. We're slapping him back into place.
					if (x < leftedge)
					x = leftedge;

					if (x > rightedge)
					x = rightedge;
				}

				if (playerBusy) {
					if (attackClock.getElapsedTime().asSeconds() > 0.017f) {
						attack_frame++;
						switch (attack_frame) {
						case 1:
							if (orientation == 1) {
								player.setTextureRect(sf::IntRect(106, 0, 94, 103));
							}
							else {
								player.setTextureRect(sf::IntRect(334, 103, 94, 103));
							}
							attackClock.restart();
							break;
						case 2:
							if (orientation == 1) {
								player.setTextureRect(sf::IntRect(236, 103, 98, 103));
							}
							else {
								player.setTextureRect(sf::IntRect(0, 206, 98, 103));
							}
							attackClock.restart();
							break;
						case 3:
							if (orientation == 1) {
								player.setTextureRect(sf::IntRect(0, 0, 106, 103));
							}
							else {
								player.setTextureRect(sf::IntRect(212, 206, 106, 103));
							}
							attackClock.restart();
							break;
						case 4:
							if (orientation == 1) {
								player.setTextureRect(sf::IntRect(200, 0, 110, 103));
							}
							else {
								player.setTextureRect(sf::IntRect(318, 206, 110, 103));
							}
							attackClock.restart();
							break;
						case 5:
							if (orientation == 1) {
								player.setTextureRect(sf::IntRect(114, 103, 122, 103));
							}
							else {
								player.setTextureRect(sf::IntRect(117, 309, 122, 103));
							}
							attackClock.restart();
							break;
						case 6:
							if (orientation == 1) {
								player.setTextureRect(sf::IntRect(310, 0, 117, 103));
							}
							else {
								player.setTextureRect(sf::IntRect(0, 309, 117, 103));
							}
							attackClock.restart();
							break;
						case 7:
							if (orientation == 1) {
								player.setTextureRect(sf::IntRect(0, 103, 114, 103));
							}
							else {
								player.setTextureRect(sf::IntRect(98, 206, 110, 103));
							}
							attackClock.restart();
							break;
						case 8:
							attack_frame = 1;
							
							if (orientation == 1) {
								player.setTextureRect(sf::IntRect(334, 309, 95, 104));
								if (((rg1_x - x > 0) and (rg1_x - x < 300)) and std::abs(y-rg1_y)<200) {
									rg1_x = width + uni(rng);
									gold = gold + 5;
								}
								if (((rg2_x - x > 0) and (rg2_x - x < 300)) and std::abs(y-rg2_y)<200) {
									rg2_x = width + uni(rng);
									gold = gold + 5;
								}
								if (((rg3_x - x > 0) and (rg3_x - x < 300)) and std::abs(y-rg3_y)<200) {
									rg3_x = width + uni(rng);
									gold = gold + 5;
								}
								if (((rg4_x - x > 0) and (rg4_x - x < 300)) and std::abs(y-rg4_y)<200) {
									rg4_x = width + uni(rng);
									gold = gold + 5;
								}
							}
							else {
								player.setTextureRect(sf::IntRect(239, 309, 95, 104));
								if (((x - rg1_x > 0) and (x - rg1_x < 300)) and std::abs(y-rg1_y)<200) {
									rg1_x = width + uni(rng);
									gold = gold + 5;
								}
								if (((x - rg2_x > 0) and (x - rg2_x < 300)) and std::abs(y-rg2_y)<200) {
									rg2_x = width + uni(rng);
									gold = gold + 5;
								}
								if (((x - rg3_x> 0) and (x - rg3_x < 300)) and std::abs(y-rg3_y)<200) {
									rg3_x = width + uni(rng);
									gold = gold + 5;
								}
								if (((x - rg4_x > 0) and (x - rg4_x < 300)) and std::abs(y-rg4_y)<200) {
									rg4_x = width + uni(rng);
									gold = gold + 5;
								}
							}
							if ((bulletx - x > 0) and (bulletx - x < 300)) {
								bullet_direction = -1;
							}
							if (((bluex - x > 0) and (bluex - x < 300)) and std::abs(y-rg1_y)<200) {
								bluex = width + uni(rng);
								gold = gold + 5;
							}
							playerBusy = false;
							attackClock.restart();
						default:
							attack_frame = 1;
							attackClock.restart();
						}
					}
				}
				// Update the player's position
				updateMovement();

				if (y > inity)
				y = inity;

				if (y == (int)inity)
				isJumping = false;

				player.setPosition(x,y);

				// Animate the red ghoul
				if (clock.getElapsedTime().asSeconds() > 0.20f) {
					if (isAttacking1 == false) {
						rg1_y = height - (height/7) - (16*rg_scale);
						if (m_frame >=3) {
							m_frame = 0;
						}
						if (rg1_x - x > 128 - 64) {
							rg1_x -= 24;
							rg1_orient = 1;
						}
						else if (rg1_x - x < -(128 - 64)) {
							rg1_x += 24;
							rg1_orient = -1;
						}
						
						if (rg1_orient == 1) {
							switch (m_frame) {
							case 0:
								red_ghoul1.setTextureRect(sf::IntRect(124, 100, 54, 49));
								break;
							case 1:
								red_ghoul1.setTextureRect(sf::IntRect(186, 100, 47, 50));
								break;
							case 2:
								red_ghoul1.setTextureRect(sf::IntRect(0, 150, 46, 48));
								break;
							}
						} else {
							switch (m_frame) {
							case 0:
								red_ghoul1.setTextureRect(sf::IntRect(62, 150, 54, 49));
								break;
							case 1:
								red_ghoul1.setTextureRect(sf::IntRect(124, 150, 47, 50));
								break;
							case 2:
								red_ghoul1.setTextureRect(sf::IntRect(186, 150, 46, 48));
								break;
							}
						}
						m_frame++;
					}
					if (isAttacking2 == false) {
						rg2_y = height - (height/7) - (16*rg_scale);
						if (m2_frame >=3) {
							m2_frame = 0;
						}
						if (rg2_x - x > 128 - 64) {
							rg2_x -= 24;
							rg2_orient = 1;
						}
						else if (rg2_x - x < -(128 - 64)) {
							rg2_x +=24;
							rg2_orient = -1;
						}
						if (rg2_orient == 1) {
							switch (m2_frame) {
							case 0:
								red_ghoul2.setTextureRect(sf::IntRect(124, 100, 54, 49));
								break;
							case 1:
								red_ghoul2.setTextureRect(sf::IntRect(186, 100, 47, 50));
								break;
							case 2:
								red_ghoul2.setTextureRect(sf::IntRect(0, 150, 46, 48));
								break;
							}
						} else {
							switch (m2_frame) {
							case 0:
								red_ghoul2.setTextureRect(sf::IntRect(62, 150, 54, 49));
								break;
							case 1:
								red_ghoul2.setTextureRect(sf::IntRect(124, 150, 47, 50));
								break;
							case 2:
								red_ghoul2.setTextureRect(sf::IntRect(186, 150, 46, 48));
								break;
							}
						}
						m2_frame++;
					}
					if (isAttacking3 == false) {
						rg3_y = height - (height/7) - (16*rg_scale);
						if (m3_frame >=3) {
							m3_frame = 0;
						}
						if (rg3_x - x > 128 - 64) {
							rg3_x -= 24;
							rg3_orient = 1;
						}
						else if (rg3_x - x < -(128 - 64)) {
							rg3_x +=24;
							rg3_orient = -1;
						}
						if (rg3_orient == 1) {
							switch (m3_frame) {
							case 0:
								red_ghoul3.setTextureRect(sf::IntRect(124, 100, 54, 49));
								break;
							case 1:
								red_ghoul3.setTextureRect(sf::IntRect(186, 100, 47, 50));
								break;
							case 2:
								red_ghoul3.setTextureRect(sf::IntRect(0, 150, 46, 48));
								break;
							}
						} else {
							switch (m3_frame) {
							case 0:
								red_ghoul3.setTextureRect(sf::IntRect(62, 150, 54, 49));
								break;
							case 1:
								red_ghoul3.setTextureRect(sf::IntRect(124, 150, 47, 50));
								break;
							case 2:
								red_ghoul3.setTextureRect(sf::IntRect(186, 150, 46, 48));
								break;
							}
						}
						m3_frame++;
					}
					if (isAttacking4 == false) {
						rg4_y = height - (height/7) - (16*rg_scale);
						if (m4_frame >=3) {
							m4_frame = 0;
						}
						if (rg4_x - x > 128 - 64) {
							rg4_x -= 24;
							rg4_orient = 1;
						}
						else if (rg4_x - x < -(128 - 64)) {
							rg4_x +=24;
							rg4_orient = -1;
						}
						if (rg4_orient == 1) {
							switch (m4_frame) {
							case 0:
								red_ghoul4.setTextureRect(sf::IntRect(124, 100, 54, 49));
								break;
							case 1:
								red_ghoul4.setTextureRect(sf::IntRect(186, 100, 47, 50));
								break;
							case 2:
								red_ghoul4.setTextureRect(sf::IntRect(0, 150, 46, 48));
								break;
							}
						} else {
							switch (m4_frame) {
							case 0:
								red_ghoul4.setTextureRect(sf::IntRect(62, 150, 54, 49));
								break;
							case 1:
								red_ghoul4.setTextureRect(sf::IntRect(124, 150, 47, 50));
								break;
							case 2:
								red_ghoul4.setTextureRect(sf::IntRect(186, 150, 46, 48));
								break;
							}
						}
						m4_frame++;
					}
					if (blue_atk == false) {
						if (blue_frame >=3) {
							blue_frame = 0;
						}
						if (bluex - width > -256) {
							bluex -= 24;
						}
						else
						blue_atk = true;
						
						switch (blue_frame) {
						case 0:
							blue.setTextureRect(sf::IntRect(0, 104, 64, 104 + 52));
							break;
						case 1:
							blue.setTextureRect(sf::IntRect(64, 104, 64*2, 104 + 52));
							break;
						case 2:
							blue.setTextureRect(sf::IntRect(128, 104, 63*3, 104 + 52));
							break;
						}
						blue_frame++;
					}
					clock.restart();
				}
				if (rg_attackClock.getElapsedTime().asSeconds() > 0.08f) {
					if ((std::abs(rg1_x - x) <= (128 + 16)) and std::abs(y-rg1_y)<200) {
						isAttacking1 = true;
						if (red_ghoul_attack_frame >= 10) {
							red_ghoul_attack_frame = 0;
							rg1_y = height - (height/7) - (16*rg_scale);
						}
						switch (red_ghoul_attack_frame) {
						case 0:
							red_ghoul1.setTextureRect(sf::IntRect(0, 0, 54, 48));
							//rg1_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 1:
							red_ghoul1.setTextureRect(sf::IntRect(62, 0, 59, 46));
							//rg1_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 2:
							red_ghoul1.setTextureRect(sf::IntRect(124, 0, 60, 46));
							//rg1_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 3:
							red_ghoul1.setTextureRect(sf::IntRect(186, 0, 62, 47));
							//rg1_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 4:
							red_ghoul1.setTextureRect(sf::IntRect(0, 50, 61, 42));
							health -= 20;
							//rg1_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 5:
							red_ghoul1.setTextureRect(sf::IntRect(0, 50, 61, 42));
							//rg1_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 6:
							red_ghoul1.setTextureRect(sf::IntRect(186, 0, 62, 47));
							//rg1_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 7:
							red_ghoul1.setTextureRect(sf::IntRect(0, 0, 54, 48));
							//rg1_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 8:
							red_ghoul1.setTextureRect(sf::IntRect(0, 0, 54, 48));
							//rg1_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 9:
							red_ghoul1.setTextureRect(sf::IntRect(0, 0, 54, 48));
							//rg1_y = height - (height/7) - (16*rg_scale) - 30;
							break;

						}
						red_ghoul_attack_frame++;
					}
					else {
						if (red_ghoul_attack_frame < 10 and red_ghoul_attack_frame > 0) {
							switch (red_ghoul_attack_frame) {
							case 0:
								red_ghoul1.setTextureRect(sf::IntRect(0, 0, 54, 48));
								//rg1_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 1:
								red_ghoul1.setTextureRect(sf::IntRect(62, 0, 59, 46));
								//rg1_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 2:
								red_ghoul1.setTextureRect(sf::IntRect(124, 0, 60, 46));
								//rg1_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 3:
								red_ghoul1.setTextureRect(sf::IntRect(186, 0, 62, 47));
								//rg1_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 4:
								red_ghoul1.setTextureRect(sf::IntRect(0, 50, 61, 42));
								health -= 20;
								//rg1_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 5:
								red_ghoul1.setTextureRect(sf::IntRect(0, 50, 61, 42));
								//rg1_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 6:
								red_ghoul1.setTextureRect(sf::IntRect(186, 0, 62, 47));
								//rg1_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 7:
								red_ghoul1.setTextureRect(sf::IntRect(0, 0, 54, 48));
								//rg1_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 8:
								red_ghoul1.setTextureRect(sf::IntRect(0, 0, 54, 48));
								//rg1_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 9:
								red_ghoul1.setTextureRect(sf::IntRect(0, 0, 54, 48));
								//rg1_y = height - (height/7) - (16*rg_scale) - 30;
								break;

							}
							red_ghoul_attack_frame++;
							if (red_ghoul_attack_frame >= 10) {
								red_ghoul_attack_frame = 0;
								rg1_y = height - (height/7) - (16*rg_scale);
								red_ghoul1.setTextureRect(sf::IntRect(124, 100, 54, 49));
							}
						}
						else {
							isAttacking1 = false;
							if (red_ghoul_attack_frame = 0) {
								rg1_y = height - (height/7) - (16*rg_scale);
								red_ghoul1.setTextureRect(sf::IntRect(124, 100, 54, 49));
							}
							if (red_ghoul_attack_frame >= 10) {
								red_ghoul_attack_frame = 0;
								rg1_y = height - (height/7) - (16*rg_scale);
								red_ghoul1.setTextureRect(sf::IntRect(124, 100, 54, 49));
							}

						}
					}
					rg_attackClock.restart();
				}
				if (rg2_attackClock.getElapsedTime().asSeconds() > 0.08f) {
					if ((std::abs(rg2_x - x) <= (128 + 16) and std::abs(y-rg2_y)<200))  {
						isAttacking2 = true;
						if (red_ghoul_attack_frame2 >= 10) {
							red_ghoul_attack_frame2 = 0;
							rg2_y = height - (height/7) - (16*rg_scale);
						}
						switch (red_ghoul_attack_frame2) {
						case 0:
							red_ghoul2.setTextureRect(sf::IntRect(0, 0, 54, 48));
							//rg2_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 1:
							red_ghoul2.setTextureRect(sf::IntRect(62, 0, 59, 46));
							//rg2_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 2:
							red_ghoul2.setTextureRect(sf::IntRect(124, 0, 60, 46));
							//rg2_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 3:
							red_ghoul2.setTextureRect(sf::IntRect(186, 0, 62, 47));
							//rg2_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 4:
							red_ghoul2.setTextureRect(sf::IntRect(0, 50, 61, 42));
							health -= 20;
							//rg2_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 5:
							red_ghoul2.setTextureRect(sf::IntRect(0, 50, 61, 42));
							//rg2_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 6:
							red_ghoul2.setTextureRect(sf::IntRect(186, 0, 62, 47));
							//rg2_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 7:
							red_ghoul2.setTextureRect(sf::IntRect(0, 0, 54, 48));
							//rg2_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 8:
							red_ghoul2.setTextureRect(sf::IntRect(0, 0, 54, 48));
							//rg2_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 9:
							red_ghoul2.setTextureRect(sf::IntRect(0, 0, 54, 48));
							//rg2_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						}
						red_ghoul_attack_frame2++;
					}
					else {
						if (red_ghoul_attack_frame2 < 10 and red_ghoul_attack_frame2 > 0) {
							switch (red_ghoul_attack_frame2) {
							case 0:
								red_ghoul2.setTextureRect(sf::IntRect(0, 0, 54, 48));
								//rg2_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 1:
								red_ghoul2.setTextureRect(sf::IntRect(62, 0, 59, 46));
								//rg2_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 2:
								red_ghoul2.setTextureRect(sf::IntRect(124, 0, 60, 46));
								//rg2_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 3:
								red_ghoul2.setTextureRect(sf::IntRect(186, 0, 62, 47));
								//rg2_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 4:
								red_ghoul2.setTextureRect(sf::IntRect(0, 50, 61, 42));
								health -= 20;
								//rg2_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 5:
								red_ghoul2.setTextureRect(sf::IntRect(0, 50, 61, 42));
								//rg2_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 6:
								red_ghoul2.setTextureRect(sf::IntRect(186, 0, 62, 47));
								//rg2_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 7:
								red_ghoul2.setTextureRect(sf::IntRect(0, 0, 54, 48));
								//rg2_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 8:
								red_ghoul2.setTextureRect(sf::IntRect(0, 0, 54, 48));
								//rg2_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 9:
								red_ghoul2.setTextureRect(sf::IntRect(0, 0, 54, 48));
								//rg2_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							}
							red_ghoul_attack_frame2++;
							if (red_ghoul_attack_frame2 >= 10) {
								red_ghoul_attack_frame2 = 0;
								rg2_y = height - (height/7) - (16*rg_scale);
								red_ghoul2.setTextureRect(sf::IntRect(124, 100, 54, 49));
							}
						}
						else {
							isAttacking2 = false;
							if (red_ghoul_attack_frame2 = 0) {
								rg2_y = height - (height/7) - (16*rg_scale);
								red_ghoul2.setTextureRect(sf::IntRect(124, 100, 54, 49));
							}
							if (red_ghoul_attack_frame2 >= 10) {
								red_ghoul_attack_frame2 = 0;
								rg2_y = height - (height/7) - (16*rg_scale);
								red_ghoul2.setTextureRect(sf::IntRect(124, 100, 54, 49));
							}
						}
					}
					rg2_attackClock.restart();
				}
				if (rg3_attackClock.getElapsedTime().asSeconds() > 0.08f) {
					if ((std::abs(rg3_x - x) <= (128 + 16) and std::abs(y-rg3_y)<200))  {
						isAttacking3 = true;
						if (red_ghoul_attack_frame3 >= 10) {
							red_ghoul_attack_frame3 = 0;
							rg3_y = height - (height/7) - (16*rg_scale);
						}
						switch (red_ghoul_attack_frame3) {
						case 0:
							red_ghoul3.setTextureRect(sf::IntRect(0, 0, 54, 48));
							//rg3_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 1:
							red_ghoul3.setTextureRect(sf::IntRect(62, 0, 59, 46));
							//rg3_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 2:
							red_ghoul3.setTextureRect(sf::IntRect(124, 0, 60, 46));
							//rg3_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 3:
							red_ghoul3.setTextureRect(sf::IntRect(186, 0, 62, 47));
							//rg3_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 4:
							red_ghoul3.setTextureRect(sf::IntRect(0, 50, 61, 42));
							health -= 20;
							//rg3_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 5:
							red_ghoul3.setTextureRect(sf::IntRect(0, 50, 61, 42));
							//rg3_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 6:
							red_ghoul3.setTextureRect(sf::IntRect(186, 0, 62, 47));
							//rg3_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 7:
							red_ghoul3.setTextureRect(sf::IntRect(0, 0, 54, 48));
							//rg3_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 8:
							red_ghoul3.setTextureRect(sf::IntRect(0, 0, 54, 48));
							//rg3_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 9:
							red_ghoul3.setTextureRect(sf::IntRect(0, 0, 54, 48));
							//rg3_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						}
						red_ghoul_attack_frame3++;
					}
					else {
						if (red_ghoul_attack_frame3 < 10 and red_ghoul_attack_frame3 > 0) {
							switch (red_ghoul_attack_frame3) {
							case 0:
								red_ghoul3.setTextureRect(sf::IntRect(0, 0, 54, 48));
								//rg3_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 1:
								red_ghoul3.setTextureRect(sf::IntRect(62, 0, 59, 46));
								//rg3_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 2:
								red_ghoul3.setTextureRect(sf::IntRect(124, 0, 60, 46));
								//rg3_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 3:
								red_ghoul3.setTextureRect(sf::IntRect(186, 0, 62, 47));
								//rg3_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 4:
								red_ghoul3.setTextureRect(sf::IntRect(0, 50, 61, 42));
								health -= 20;
								//rg3_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 5:
								red_ghoul3.setTextureRect(sf::IntRect(0, 50, 61, 42));
								// rg3_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 6:
								red_ghoul3.setTextureRect(sf::IntRect(186, 0, 62, 47));
								//rg3_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 7:
								red_ghoul3.setTextureRect(sf::IntRect(0, 0, 54, 48));
								//rg3_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 8:
								red_ghoul3.setTextureRect(sf::IntRect(0, 0, 54, 48));
								//rg3_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 9:
								red_ghoul3.setTextureRect(sf::IntRect(0, 0, 54, 48));
								//rg3_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							}
							red_ghoul_attack_frame3++;
							if (red_ghoul_attack_frame3 >= 10) {
								red_ghoul_attack_frame3 = 0;
								rg3_y = height - (height/7) - (16*rg_scale);
								red_ghoul3.setTextureRect(sf::IntRect(124, 100, 54, 49));
							}
						}
						else {
							isAttacking3 = false;
							if (red_ghoul_attack_frame3 = 0) {
								rg3_y = height - (height/7) - (16*rg_scale);
								red_ghoul3.setTextureRect(sf::IntRect(124, 100, 54, 49));
							}
							if (red_ghoul_attack_frame3 >= 10) {
								red_ghoul_attack_frame3 = 0;
								rg3_y = height - (height/7) - (16*rg_scale);
								red_ghoul3.setTextureRect(sf::IntRect(124, 100, 54, 49));
							}
						}
					}
					rg3_attackClock.restart();
				}
				if (rg4_attackClock.getElapsedTime().asSeconds() > 0.08f) {
					if ((std::abs(rg4_x - x) <= (128 + 16) and std::abs(y-rg4_y)<200))  {
						isAttacking4 = true;
						if (red_ghoul_attack_frame4 >= 10) {
							red_ghoul_attack_frame4 = 0;
							rg4_y = height - (height/7) - (16*rg_scale);
						}
						switch (red_ghoul_attack_frame4) {
						case 0:
							red_ghoul4.setTextureRect(sf::IntRect(0, 0, 54, 48));
							//rg4_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 1:
							red_ghoul4.setTextureRect(sf::IntRect(62, 0, 59, 46));
							//rg4_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 2:
							red_ghoul4.setTextureRect(sf::IntRect(124, 0, 60, 46));
							//rg4_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 3:
							red_ghoul4.setTextureRect(sf::IntRect(186, 0, 62, 47));
							//rg4_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 4:
							red_ghoul4.setTextureRect(sf::IntRect(0, 50, 61, 42));
							health -= 20;
							//rg4_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 5:
							red_ghoul4.setTextureRect(sf::IntRect(0, 50, 61, 42));
							//rg4_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 6:
							red_ghoul4.setTextureRect(sf::IntRect(186, 0, 62, 47));
							//rg4_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 7:
							red_ghoul4.setTextureRect(sf::IntRect(0, 0, 54, 48));
							//rg4_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 8:
							red_ghoul4.setTextureRect(sf::IntRect(0, 0, 54, 48));
							//rg4_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						case 9:
							red_ghoul4.setTextureRect(sf::IntRect(0, 0, 54, 48));
							//rg4_y = height - (height/7) - (16*rg_scale) - 30;
							break;
						}
						red_ghoul_attack_frame4++;
					}
					else {
						if (red_ghoul_attack_frame4 < 10 and red_ghoul_attack_frame4 > 0) {
							switch (red_ghoul_attack_frame4) {
							case 0:
								red_ghoul4.setTextureRect(sf::IntRect(0, 0, 54, 48));
								//rg4_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 1:
								red_ghoul4.setTextureRect(sf::IntRect(62, 0, 59, 46));
								//rg4_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 2:
								red_ghoul4.setTextureRect(sf::IntRect(124, 0, 60, 46));
								//rg4_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 3:
								red_ghoul4.setTextureRect(sf::IntRect(186, 0, 62, 47));
								//rg4_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 4:
								red_ghoul4.setTextureRect(sf::IntRect(0, 50, 61, 42));
								health -= 20;
								//rg4_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 5:
								red_ghoul4.setTextureRect(sf::IntRect(0, 50, 61, 42));
								//rg4_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 6:
								red_ghoul4.setTextureRect(sf::IntRect(186, 0, 62, 47));
								//rg4_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 7:
								red_ghoul4.setTextureRect(sf::IntRect(0, 0, 54, 48));
								//rg4_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 8:
								red_ghoul4.setTextureRect(sf::IntRect(0, 0, 54, 48));
								//rg4_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							case 9:
								red_ghoul4.setTextureRect(sf::IntRect(0, 0, 54, 48));
								//rg4_y = height - (height/7) - (16*rg_scale) - 30;
								break;
							}
							red_ghoul_attack_frame4++;
							if (red_ghoul_attack_frame4 >= 10) {
								red_ghoul_attack_frame4 = 0;
								rg4_y = height - (height/7) - (16*rg_scale);
								red_ghoul4.setTextureRect(sf::IntRect(124, 100, 54, 49));
							}
						}
						else {
							isAttacking4 = false;
							if (red_ghoul_attack_frame4 = 0) {
								rg4_y = height - (height/7) - (16*rg_scale);
								red_ghoul4.setTextureRect(sf::IntRect(124, 100, 54, 49));
							}
							if (red_ghoul_attack_frame4 >= 10) {
								red_ghoul_attack_frame4 = 0;
								rg4_y = height - (height/7) - (16*rg_scale);
								red_ghoul4.setTextureRect(sf::IntRect(124, 100, 54, 49));
							}
						}
					}
					rg4_attackClock.restart();
				}
				if (blue_atk && stop_anim == false) {
					if (blue_clock.getElapsedTime().asSeconds() > 0.10f) {
						if (blue_atk_frame > 12)
						blue_atk_frame = 0;
						switch (blue_atk_frame) {
						case 1:
							blue.setTextureRect(sf::IntRect(0, 0, 64, 52));
							break;
						case 2:
							blue.setTextureRect(sf::IntRect(64, 0, 64, 52));
							break;
						case 3:
							blue.setTextureRect(sf::IntRect(128, 0, 64, 52));
							break;
						case 4:
							blue.setTextureRect(sf::IntRect(192, 0, 64, 52));
							break;
						case 5:
							blue.setTextureRect(sf::IntRect(0, 52, 64, 52));
							break;
						case 6:
							blue.setTextureRect(sf::IntRect(64, 52, 64, 52));
							break;
						case 7:
							blue.setTextureRect(sf::IntRect(64, 52, 64, 52));
							bullet_spawn = true;
							bulletx = bluex-128-16;
							bullety = bluey-64-20;
							bullet_direction = 1;
							bullet.setPosition(bulletx, bullety);
							break;
						case 8:
							blue.setTextureRect(sf::IntRect(192, 52, 64, 52));
							stop_anim = true;
							break;
						}
						blue_atk_frame++;
						blue_clock.restart();
					}
					
				}
				if (bullet_spawn) {
					if (bulletClock.getElapsedTime().asSeconds() > 0.10f) {
						if (bullet_direction == 1) {
							bulletx -= 32;
							bulletClock.restart();
						}
						else {
							bulletx += 64;
							bulletClock.restart();
						}
					}
					if ((bluex - bulletx < 128) && (bullet_direction == -1)) {
						bluex = width + uni(rng) + 1024;
						bulletx = 9000;
						gold += 5;
						bullet_spawn = false;
						stop_anim = false;
						blue_atk = false;
					}
					if ((bulletx - x < 64) && (bullet_direction == 1)) {
						bulletx = 9000;
						bullet_spawn = false;
						stop_anim = false;
						health -= 20;
					}
				}
			}
			if ((mana > 100) or (mana < 0)) {
				mana = 0;
			}

			if (mana_clock.getElapsedTime().asSeconds() > 0.20f && isPause == false && health != 0) {
				if (mana < 100) {
					mana += 1;
					mana_clock.restart();
				}
			}

			if (health < 1) {
				isPlaying = false;
			}

			if (isPlaying == false && health < 1) {
				player.setColor(sf::Color(255, 255, 255, 150));
				if (endscreeny != -20) {
					if (endClock.getElapsedTime().asSeconds() > 0.020f) {
						endscreeny = endscreeny + 20;
						endscreen.setPosition(endscreenx, endscreeny);
						endClock.restart();
					}
				}
				if (endscreeny == -20) {
					if (sf::Keyboard::isKeyPressed(sf::Keyboard::Enter)) {
						return EXIT_SUCCESS;
					}
					if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
						if (((mouse.x > endscreenx + 156) && (mouse.x < endscreenx + 535)) && ((mouse.y > endscreeny - 20 + 275) && (mouse.y < endscreeny - 20 + 335))) {
							rg1_x = width + 256;
							rg1_y = height - (height/7) - (16*rg_scale);
							rg2_y = height - (height/7) - (16*rg_scale);
							rg3_y = height - (height/7) - (16*rg_scale);
							rg4_y = height - (height/7) - (16*rg_scale);
							rg2_x = width + 256 + 256;
							rg3_x = width + 256 + 512;
							rg4_x = width + 256 + 512 + 256;
							bluex = width + 2048 + uni(rng);
							y = inity;
							x = 128+128;
							health = 100;
							mana = 100;
							gold = 0;
							player.setPosition(x, y);
							red_ghoul1.setPosition(rg1_x, rg1_y);
							red_ghoul2.setPosition(rg2_x, rg2_y);
							red_ghoul3.setPosition(rg3_x, rg3_y);
							red_ghoul4.setPosition(rg4_x, rg4_y);
							player.setColor(sf::Color(255, 255, 255, 255));
							isPlaying = true;
						}
						if (((mouse.x > endscreenx + 200) && (mouse.x < endscreenx + 570)) && ((mouse.y > endscreeny - 20 + 666) && (mouse.y < endscreeny - 20 + 735))) {
							return EXIT_SUCCESS;
						}
					}
				}
			}

			if (isPause == true && health > 0) {
				isPlaying = false;
				if (menuy != -20) {
					if (endClock.getElapsedTime().asSeconds() > 0.020f) {
						menuy = menuy + 20;
						menu.setPosition(menux, menuy);
						endClock.restart();
					}
				}
				if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
					if (((mouse.x > menux + 156) && (mouse.x < menux + 535)) && ((mouse.y > menuy - 20 + 275) && (mouse.y < menuy - 20 + 335))) {
						isPause = false;
					}
					if (((mouse.x > menux + 200) && (mouse.x < menux + 570)) && ((mouse.y > menuy - 20 + 666) && (mouse.y < menuy - 20 + 735))) {
						return EXIT_SUCCESS;
					}
				}
			}

			if (isPause == false && health > 0) {
				if (menuy != -800) {
					isPlaying = true;
					if (endClock.getElapsedTime().asSeconds() > 0.001f) {
						menuy = menuy - 20;
						menu.setPosition(menux, menuy);
						endClock.restart();
					}
				}
				if (endscreeny != -800) {
					if (endClock.getElapsedTime().asSeconds() > 0.001f) {
						endscreeny = endscreeny - 20;
						endscreen.setPosition(endscreenx, endscreeny);
						endClock.restart();
					}
				}
			}
			health_bar.setTextureRect(sf::IntRect(0, 0, health/0.862, 58*0.862));
			mana_bar.setTextureRect(sf::IntRect(0, 0, mana/0.862, 58*0.862));
			health_str = std::to_string(health);
			health_val.setString(health_str);

			mana_str = std::to_string(mana);
			mana_val.setString(mana_str);

			gold_str = std::to_string(gold);
			gold_val.setString(gold_str);

			int goldpos = NumDigits(gold);
			gold_val.setPosition(width - (16 + 13*goldpos), 16);

			red_ghoul1.setPosition(rg1_x, rg1_y);
			red_ghoul2.setPosition(rg2_x, rg2_y);
			red_ghoul3.setPosition(rg3_x, rg3_y);
			red_ghoul4.setPosition(rg4_x, rg4_y);
			blue.setPosition(bluex, bluey);
			bullet.setPosition(bulletx, bullety);

			// Clear the screen, redraw the sprites and render them;
			window.draw(background);
			window.draw(player);
			window.draw(blue);
			window.draw(red_ghoul1);
			window.draw(red_ghoul2);
			window.draw(red_ghoul3);
			window.draw(red_ghoul4);
			window.draw(bullet);
			window.draw(status_bar);
			window.draw(health_bar);
			window.draw(mana_bar);
			window.draw(health_val);
			window.draw(mana_val);
			window.draw(gold_val);
			window.draw(endscreen);
			window.draw(menu);
		}
	window.display();
	}
	return EXIT_SUCCESS;
}